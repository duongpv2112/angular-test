<template>
    <div class="msc-main-app">
        <TheHeader />
        <TheContainer />
        <TheFooter />
    </div>
</template>

<script>
import TheContainer from './components/layouts/TheContainer/TheContainer.vue';
import TheFooter from './components/layouts/TheFooter/TheFooter.vue';
import TheHeader from './components/layouts/TheHeader/TheHeader.vue';


export default {
    name: 'App',
    components: {
        TheHeader,
        TheContainer,
        TheFooter
    }
}
</script>

<style>
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}

body {
    font-size: 13px;
    font-family: Arial, Helvetica, sans-serif;
}
</style>
