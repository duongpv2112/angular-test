<template>
    <div class="msc-main-container">
        <router-view></router-view>
    </div>
</template>
<script>
export default {
    name: "TheContainer"
}
</script>
<style lang="css" scoped>
@import "./TheContainer.css";
.msc-main-container {
    margin-top: 56px;
    height: calc(100vh - 56px);
}
</style>