<template>
    <div>

    </div>
</template>
<script>
export default {
    name: "TheFooter"
}
</script>
<style lang="css" scoped>
@import "./TheFooter.css";
</style>