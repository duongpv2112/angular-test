<template>
    <div class="msc-main-header">

    </div>
</template>
<script>

export default {
    name: "TheHeader",
    components: {
    },
}
</script>
<style lang="css" scoped>
@import "./TheHeader.css";

.msc-main-header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: 56px;
    box-shadow: 0 1px 3px rgb(0 0 0 / 8%);
    background-color: #fff;
    z-index: 99;
}
</style>