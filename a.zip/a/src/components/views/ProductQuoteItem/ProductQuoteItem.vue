<template>
    <div class="msc-item-card-wrap">
        <div class="msc-item-card">
            <div class="item-card-name">
                <span>Starter</span>
            </div>
            <div class="item-card-under-line">

            </div>

            <div class="item-card-price">
                <span>2.450.000</span>
            </div>

            <div class="item-card-unit">
                <span>VND/Năm</span>
            </div>

            <div class="item-card-button">
                Mua ngay
            </div>

            <div class="item-card-desc">
                <div class="item-card-view-desc">
                    <div class="desc-detail">
                        <div class="icon-item">

                        </div>

                        <div class="item-text">
                            <span>Gói 01 người dùng</span>
                        </div>
                    </div>

                    <div class="desc-detail">
                        <div class="icon-item">

                        </div>

                        <div class="item-text">
                            <span>08 nghiệp vụ: Quỹ, Thủ Quỹ, Ngân hàng, Bán hàng, Quản lý hoá đơn, Thuế, Thuế điện tử (MISA
                                Mtax), Tổng hợp</span>
                        </div>
                    </div>

                    <div class="desc-detail">
                        <div class="icon-item">

                        </div>

                        <div class="item-text">
                            <span>Ngân hàng điện tử (JetPay BankHub) 1000 Chứng từ/Năm</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>

export default {
    name: "ProductQuoteItem",
    components: {
    }
}
</script>
<style scoped lang="css">
@import "./ProductQuoteItem.css";
</style>