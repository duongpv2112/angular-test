import { createRouter, createWebHistory } from "vue-router";

import PlatformPage from "../views/PlatformPage/PlatformView.vue";
import CartPage from "../views/CartPage/CartView.vue";
import QuotePage from "../views/QuotePage/QuoteView.vue";

/* Khai báo các router */
const routes = [
    {
        path: "/",
        redirect: {
            name: "platform",
        },
    },
    { path: "/platform", name: "platform", component: PlatformPage },
    { path: "/quote", name: "quote", component: QuotePage },
    { path: "/cart", name: "cart", component: CartPage },
];

/* Khởi tạo router */
const vueRouter = createRouter({
    history: createWebHistory(),
    routes: routes,
});

export default vueRouter;
