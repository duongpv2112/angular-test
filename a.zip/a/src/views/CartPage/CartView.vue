<template>
    <div>
    </div>
</template>
<script>
export default {
    name: "CartView"
}
</script>
<style scoped>
</style>