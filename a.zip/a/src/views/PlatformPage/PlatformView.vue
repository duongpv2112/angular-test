<template>
    <div>
        <button>
            <router-link :to="{ name: 'quote' }">Mua ngay</router-link>
        </button>
    </div>
</template>
<script>
export default {
    name: "PlatformPage"
}
</script>
<style scoped>
</style>