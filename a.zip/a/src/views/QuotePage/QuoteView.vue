<template>
    <div class="msc-quote-container">
        <div class="msc-quote-background">
            <div class="background-quote-color">
            </div>
        </div>

        <div class="msc-quote-header">
            <div class="msc-quote-title">
                <span>Báo giá phần mềm AMIS Kế toán</span>
            </div>

            <div class="msc-quote-sub-title">
                <span>Chọn một gói sản phẩm phù hợp với nhu cầu doanh nghiệp của bạn</span>
            </div>

            <div class="msc-quote-options">
                <div class="quote-option-item actived">
                    <span>Doanh nghiệp</span>
                </div>

                <div class="quote-option-item">
                    <span>Hộ, cá nhân kinh doanh</span>
                </div>
            </div>
        </div>

        <div class="msc-quote-content">
            <div class="msc-quote-card">
                <div class="list-item-container">
                    <ProductQuoteItem />
                    <ProductQuoteItem />
                    <ProductQuoteItem />
                    <ProductQuoteItem />
                    <ProductQuoteItem />
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import ProductQuoteItem from "../../components/views/ProductQuoteItem/ProductQuoteItem.vue"
export default {
    name: "QuotePage",
    components: {
        ProductQuoteItem
    }
}
</script>
<style scoped lang="css">
@import "./QuoteView.css";
</style>